% example regression with two independant inputs, one measured output
% X, Y (independant variables), Dependant_Var are column vectors

% create some fake data
 rand('twister',3223111); % initialize random number generator to get same results each time
 X = rand(500,1);
 Y = rand(500,1);
 err = .95+.1.*rand(500,1); % add some random noise just for the fun if it
Dependant_Var = (.82 + .45.*log(X) + 1.33.*Y).*err; % resultant data 


% This is the key to the regression - defining the form!!!
ii = ones(size(X)); % a "constant state"
states = [ii X X.^4 Y Y.^2];  % create a state variable for an equation of the form:
                        % expected_value = a1 + a2*X + a3*X^4 + a4*Y + a5*Y^2
                  % NOTE:
                  %.^ used for element by element operation instead of matrix power      
numstates = size(states,2);

% backslash operator performs the least square fit to solve the equation
    % Dependant_Var = coeff*states 
    
coeff = states\Dependant_Var;  % determine regression coeficients (a1 - a4 in equation above)

xpected = states * coeff;     % determine expected (regressed) values at each data point

resid = xpected - Dependant_Var; % calculate residuals 
        % difference between expected values from the regression 
        % minus the actual Y values: regressed - actual

% error varience (s^2) = residual sum of squares / degrees of freedom
% degrees of freedom = number of samples - number of parameters estimated.
% standard deviation = sqrt(varience)

resid_sum_sq = sum(resid.*resid);  % sum of squares of residuals
dof = length(X) - length(coeff);    % degrees of freedom
var_err = resid_sum_sq/dof;         % varience of the error
std_dev_err = sqrt(var_err);%  % calculate standard deviation of error

% varience of coefficients

% do some sum of squares stuff ahead of time.
p1 = states(:,1); p2 = sum(states(:,1).^2);
for ii = 2:numstates
    p1 = p1.*states(:,ii);
    p2  = p2 .*sum(states(:,ii).^2);
end
% correlation cooefficient
corr = -1*sum(p1)./sqrt(p2);


disp('coefficient   standard error')
for ii = 1:numstates
    var_x(ii) = (1./(1-corr.^2)).*(var_err./sum(states(:,ii).^2));
    std_err(ii) = sqrt(var_x(ii));
    disp([coeff(ii), std_err(ii)])
    
    
end


R2 = r_squared(Dependant_Var,resid); % calculate R squared statistic
disp(['R Squared = ',num2str(R2)])

minX = min(X); maxX = max(X); deltaX = (maxX-minX)/20;  % set up mesh parameters for 3 d plot
minY = min(Y); maxY = max(Y); deltaY = (maxY-minY)/20;

[XX YY] = meshgrid([minX:deltaX:maxX], [minY:deltaY:maxY]); % generate grid for surface / mesh plot

ZZ = ones(size(XX)).*coeff(1) + XX.*coeff(2) + YY.*coeff(3) + (YY.^2).*coeff(4) +(YY.^3).*coeff(5);
%ZZ = ones(size(XX)).*coeff(1) + log(XX).*coeff(2) + (1./YY).*coeff(3);

figure(1)
mesh(XX,YY,ZZ, 'FaceColor','None')
hold on
plot3(X,Y,Dependant_Var,'*')
hold off
xlabel('X')
ylabel('Y')
zlabel('Dependant Variable')
title(['Example Data Regression R Squared = ', num2str(R2)])
