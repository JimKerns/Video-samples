
% create some fake data for illustration purpouses. This section would be replaced by actual X and Y data. 
rand('twister',3223111); % initialize random number generator to get same results each time
X = rand(50,1); % collumn vector with 50 values between 0 and 1
Y = .5 + 1.2.*X + 3.*X.^5; % "sample" data created via an arbitrary equation

% for a real problem, the actual X and Y values would be entered here. 

n = 3; % fit the data to an nth order polynomial

A = polyfit(X,Y,n) % fit a n order polynomial to the X and Y data 
                    %A will be a vector of the coefficients for: a0 + a1*X + a2*X^2 +... an*X^n

xx = [-.5:.01:1.5]; % generate a bunch of points for plotting that correlates to the range of X values
yy = polyval(A,xx); % generate expected values from the regression for each value of xx.


figure(1) % create a figure 
plot(X,Y,'*',xx,yy,'r') % plot the actual and expected data. 
grid
title([num2str(n),' order fit'])


resid = polyval(A,X) - Y;
r_sq = r_squared(Y,resid)